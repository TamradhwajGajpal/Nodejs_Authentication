module.exports = {
    MongoURI: "mongodb+srv://aryanbaba4199:Aryan7277@cluster0.moy3ovh.mongodb.net/Authentication?retryWrites=true&w=majority"
}